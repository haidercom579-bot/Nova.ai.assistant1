import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '15mb' }));

// Health / Status endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    model: 'gemini-4-hydrogen',
  });
});

// Download project archive endpoint
app.get('/api/download-project', (req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'nova-app-project.zip');
  if (!fs.existsSync(zipPath)) {
    return res.status(404).json({ success: false, error: 'Project zip archive not found.' });
  }
  return res.download(zipPath, 'nova-app-project.zip');
});

// Candidate models in order of preference (per Google AI Studio guidelines)
// Highest free-tier model: gemini-4-hydrogen, followed by fast fallback gemini-3.1-flash-lite
const CANDIDATE_MODELS = [
  'gemini-4-hydrogen',
  'gemini-3.1-flash-lite',
];

// Chat endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, systemInstruction, useSearchGrounding, requestedModel, reasoningMode } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(200).json({
        success: false,
        error: 'Please enter a message to begin chatting.',
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(200).json({
        success: false,
        error: 'API key is not configured. Please check your environment variables in Settings > Secrets.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Clean and validate messages (including optional text/image attachments)
    const cleaned = messages
      .filter(
        (m: any) =>
          m &&
          !m.isError &&
          ((typeof m.content === 'string' && m.content.trim().length > 0) || Boolean(m.attachment))
      )
      .map((m: any) => {
        const parts: any[] = [];
        const rawText = typeof m.content === 'string' ? m.content.trim() : '';

        if (m.attachment && typeof m.attachment === 'object') {
          if (m.attachment.kind === 'image' && m.attachment.content && m.attachment.mimeType) {
            parts.push({
              inlineData: {
                mimeType: m.attachment.mimeType,
                data: m.attachment.content,
              },
            });
          } else if (m.attachment.kind === 'text' && m.attachment.content) {
            const fileHeader = `[Attached file: ${m.attachment.name || 'file'}]\n\`\`\`\n${String(m.attachment.content).slice(0, 60000)}\n\`\`\``;
            parts.push({ text: rawText ? `${fileHeader}\n\n${rawText}` : fileHeader });
          }
        }

        if (parts.length === 0 || (m.attachment?.kind === 'image' && rawText)) {
          parts.push({ text: rawText || 'Please analyze the attached file.' });
        }

        return {
          role: (m.role === 'user' ? 'user' : 'model') as 'user' | 'model',
          parts,
        };
      });

    if (cleaned.length === 0) {
      return res.status(200).json({
        success: false,
        error: 'Please enter a valid message.',
      });
    }

    // Merge consecutive messages from the same role
    const mergedContents: { role: 'user' | 'model'; parts: any[] }[] = [];
    for (const msg of cleaned) {
      if (mergedContents.length > 0 && mergedContents[mergedContents.length - 1].role === msg.role) {
        mergedContents[mergedContents.length - 1].parts.push(...msg.parts);
      } else {
        mergedContents.push({
          role: msg.role,
          parts: [...msg.parts],
        });
      }
    }

    while (mergedContents.length > 0 && mergedContents[0].role !== 'user') {
      mergedContents.shift();
    }

    if (mergedContents.length === 0) {
      mergedContents.push({
        role: 'user',
        parts: [...cleaned[cleaned.length - 1].parts],
      });
    }

    const defaultSystemInstruction =
      "You are NOVA, a personal AI assistant. Your tone is warm, friendly, helpful, articulate, and honest.\n" +
      "Guidelines:\n" +
      "- Answer questions accurately and explain complex or technical topics in simple, intuitive terms.\n" +
      "- Enthusiastically assist with studying, brainstorming, writing, editing, problem-solving, and creative projects.\n" +
      "- If you do not know the answer or lack verified facts, clearly state that you don't know instead of inventing information.\n" +
      "- Use structured formatting like short paragraphs, bullet points, numbered steps, or markdown code blocks to make reading easy.\n" +
      "- Keep your responses focused, helpful, and supportive.";

    // Normalize requested model so stale/deprecated model IDs map cleanly to gemini-4-hydrogen
    const normalizedRequestedModel =
      typeof requestedModel === 'string' && CANDIDATE_MODELS.includes(requestedModel)
        ? requestedModel
        : 'gemini-4-hydrogen';

    // Determine models to try, prioritizing requested model with fallback
    const modelsToTry: string[] = [
      normalizedRequestedModel,
      ...CANDIDATE_MODELS.filter((m) => m !== normalizedRequestedModel),
    ];

    let lastError: any = null;
    let successfulText = '';
    let usedModel = '';
    let groundingSources: { title: string; url: string }[] = [];

    for (const model of modelsToTry) {
      try {
        const generateConfig: any = {
          systemInstruction: systemInstruction || defaultSystemInstruction,
        };

        if (reasoningMode && model === 'gemini-4-hydrogen') {
          generateConfig.thinkingConfig = {
            thinkingLevel: ThinkingLevel.XHIGH,
          };
        }

        if (useSearchGrounding) {
          generateConfig.tools = [{ googleSearch: {} }];
        }

        const withTimeout = async (fn: () => Promise<any>, ms: number = 25000) => {
          let timer: any;
          const timeoutPromise = new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error(`Model ${model} timed out after ${ms}ms`)), ms);
          });
          try {
            return await Promise.race([fn(), timeoutPromise]);
          } finally {
            clearTimeout(timer);
          }
        };

        let response: any;
        try {
          response = await withTimeout(() =>
            ai.models.generateContent({
              model,
              contents: mergedContents,
              config: generateConfig,
            })
          );
        } catch (groundingErr: any) {
          // If search grounding hits rate limit / quota, fall back to generation without tools
          if (useSearchGrounding) {
            delete generateConfig.tools;
            response = await withTimeout(() =>
              ai.models.generateContent({
                model,
                contents: mergedContents,
                config: generateConfig,
              })
            );
          } else {
            throw groundingErr;
          }
        }

        const text = response.text;
        if (text) {
          successfulText = text;
          usedModel = model;

          // Extract grounding metadata if present
          const candidate = response.candidates?.[0];
          const metadata = (candidate as any)?.groundingMetadata;
          if (metadata && Array.isArray(metadata.groundingChunks)) {
            for (const chunk of metadata.groundingChunks) {
              if (chunk?.web?.uri) {
                groundingSources.push({
                  title: chunk.web.title || chunk.web.uri,
                  url: chunk.web.uri,
                });
              }
            }
          }
          break;
        }
      } catch (err: any) {
        lastError = err;
        const errMsg = String(err?.message || '');
        console.warn(`Model ${model} attempt failed: ${errMsg.slice(0, 120)}. Trying fallback...`);
      }
    }

    if (successfulText) {
      return res.status(200).json({
        success: true,
        text: successfulText,
        model: usedModel,
        groundingSources: groundingSources.length > 0 ? groundingSources : undefined,
      });
    }

    const errorDetail = lastError?.message || '';
    let friendlyMessage = 'NOVA is experiencing unusually high demand right now. Please click "Try Again" in a moment.';
    if (errorDetail.includes('API_KEY') || errorDetail.includes('key')) {
      friendlyMessage = 'Invalid or missing API key. Please check the Secrets configuration.';
    }

    return res.status(200).json({
      success: false,
      error: friendlyMessage,
    });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    return res.status(200).json({
      success: false,
      error: 'An unexpected error occurred while communicating with NOVA. Please try again.',
    });
  }
});

// Auto-Summarize conversation endpoint
app.post('/api/summarize', async (req: Request, res: Response) => {
  try {
    const { messages, requestedModel } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(200).json({
        success: false,
        error: 'There are no messages to summarize yet.',
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(200).json({
        success: false,
        error: 'API key is not configured. Please check your environment variables in Settings > Secrets.',
      });
    }

    const transcriptLines = messages
      .filter(
        (m: any) =>
          m &&
          !m.isError &&
          ((typeof m.content === 'string' && m.content.trim().length > 0) || Boolean(m.attachment))
      )
      .map((m: any) => {
        const speaker = m.role === 'user' ? 'User' : 'NOVA';
        const text = typeof m.content === 'string' ? m.content.trim() : '';
        const attachmentNote = m.attachment?.name ? `[Attachment: ${m.attachment.name}] ` : '';
        return `${speaker}: ${attachmentNote}${text}`.trim();
      });

    if (transcriptLines.length === 0) {
      return res.status(200).json({
        success: false,
        error: 'No valid conversation messages found to summarize.',
      });
    }

    const transcript = transcriptLines.join('\n\n').slice(-45000);

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const normalizedRequestedModel =
      typeof requestedModel === 'string' && CANDIDATE_MODELS.includes(requestedModel)
        ? requestedModel
        : 'gemini-4-hydrogen';

    const modelsToTry: string[] = [
      normalizedRequestedModel,
      ...CANDIDATE_MODELS.filter((m) => m !== normalizedRequestedModel),
    ];

    let summaryText = '';
    let usedModel = '';
    let lastError: any = null;

    for (const model of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: `Summarize the following conversation concisely:\n\n${transcript}`,
          config: {
            systemInstruction:
              'You are a concise conversation summarizer. Summarize the conversation history in 2 to 4 clear sentences (under 85 words total) covering the main topic, key answers or decisions, and any next steps. Do not use markdown headers or filler.',
          },
        });

        const text = response.text?.trim();
        if (text) {
          summaryText = text;
          usedModel = model;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`Summarize with ${model} failed: ${String(err?.message || '').slice(0, 120)}`);
      }
    }

    if (summaryText) {
      return res.status(200).json({
        success: true,
        summary: summaryText,
        model: usedModel,
      });
    }

    return res.status(200).json({
      success: false,
      error: lastError?.message || 'Could not generate a summary right now. Please try again.',
    });
  } catch (error: any) {
    console.error('Error in /api/summarize:', error);
    return res.status(200).json({
      success: false,
      error: 'An unexpected error occurred while summarizing the conversation.',
    });
  }
});

// Audio transcription endpoint using gemini-3.5-transcribe
app.post('/api/transcribe', async (req: Request, res: Response) => {
  try {
    const { audioBase64, mimeType = 'audio/webm' } = req.body;

    if (!audioBase64) {
      return res.status(400).json({
        success: false,
        error: 'No audio data received for transcription.',
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        success: false,
        error: 'API key is not configured.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const audioPart = {
      inlineData: {
        mimeType,
        data: audioBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [audioPart, { text: 'Transcribe this spoken audio accurately into text.' }],
      },
    });

    const transcript = response.text || '';

    return res.status(200).json({
      success: true,
      text: transcript.trim(),
      model: 'gemini-3.5-transcribe',
    });
  } catch (error: any) {
    console.error('Transcription error:', error);
    return res.status(200).json({
      success: false,
      error: error?.message || 'Could not transcribe audio.',
    });
  }
});

// --- WORK AGENT & ENABLE KEY AUTHENTICATION ---
interface ServerAgentKeyRecord {
  agentId: string;
  keyHash: string;
  maskedKey: string;
  status: 'active' | 'inactive';
  quickAccessEnabled: boolean;
  floatingIconEnabled: boolean;
  createdAt: number;
}

const AGENT_KEY_STORE_PATH = '/tmp/nova-agent-keys.json';
const agentKeyStore = new Map<string, ServerAgentKeyRecord>();

function loadAgentKeyStore() {
  try {
    if (fs.existsSync(AGENT_KEY_STORE_PATH)) {
      const raw = JSON.parse(fs.readFileSync(AGENT_KEY_STORE_PATH, 'utf-8'));
      if (Array.isArray(raw)) {
        for (const rec of raw) {
          if (rec?.agentId && rec?.keyHash) {
            agentKeyStore.set(rec.agentId, rec);
          }
        }
      }
    }
  } catch (e) {
    console.warn('Could not load agent key store:', e);
  }
}

function persistAgentKeyStore() {
  try {
    fs.writeFileSync(
      AGENT_KEY_STORE_PATH,
      JSON.stringify(Array.from(agentKeyStore.values()), null, 2)
    );
  } catch (e) {
    console.warn('Could not persist agent key store:', e);
  }
}

loadAgentKeyStore();

function hashAccessKey(rawKey: string): string {
  return crypto.createHash('sha256').update(rawKey).digest('hex');
}

function maskAccessKey(rawKey: string): string {
  if (rawKey.length <= 12) return 'nova_wk_••••';
  return `${rawKey.slice(0, 11)}••••••••${rawKey.slice(-4)}`;
}

function isSafeHttpsUrl(rawUrl?: string): boolean {
  if (!rawUrl || typeof rawUrl !== 'string') return false;
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

// Generate or regenerate a secure WORK Agent access key
app.post('/api/agent/key/generate', (req: Request, res: Response) => {
  const agentId = typeof req.body?.agentId === 'string' && req.body.agentId.trim()
    ? req.body.agentId.trim()
    : '101';

  const randomToken = crypto.randomBytes(24).toString('base64url');
  const rawKey = `nova_wk_${randomToken}`;
  const maskedKey = maskAccessKey(rawKey);
  const existing = agentKeyStore.get(agentId);

  const record: ServerAgentKeyRecord = {
    agentId,
    keyHash: hashAccessKey(rawKey),
    maskedKey,
    status: 'active',
    quickAccessEnabled: existing ? existing.quickAccessEnabled : true,
    floatingIconEnabled: existing ? existing.floatingIconEnabled : true,
    createdAt: Date.now(),
  };

  agentKeyStore.set(agentId, record);
  persistAgentKeyStore();

  return res.status(200).json({
    success: true,
    agentId: record.agentId,
    accessKey: rawKey,
    maskedKey: record.maskedKey,
    status: record.status,
    quickAccessEnabled: record.quickAccessEnabled,
    floatingIconEnabled: record.floatingIconEnabled,
    createdAt: record.createdAt,
  });
});

// Update key / Quick Access status
app.post('/api/agent/key/status', (req: Request, res: Response) => {
  const { agentId = '101', status, quickAccessEnabled, floatingIconEnabled } = req.body || {};
  const authHeader = req.headers.authorization || '';
  const bearerKey = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';

  const record = agentKeyStore.get(String(agentId));
  if (!record) {
    return res.status(404).json({
      success: false,
      error: 'No access key found for this agent. Generate a key first.',
    });
  }

  if (bearerKey && hashAccessKey(bearerKey) !== record.keyHash) {
    return res.status(401).json({
      success: false,
      error: 'Invalid access key for this WORK Agent.',
    });
  }

  if (status === 'active' || status === 'inactive') {
    record.status = status;
  }
  if (typeof quickAccessEnabled === 'boolean') {
    record.quickAccessEnabled = quickAccessEnabled;
  }
  if (typeof floatingIconEnabled === 'boolean') {
    record.floatingIconEnabled = floatingIconEnabled;
  }

  agentKeyStore.set(String(agentId), record);
  persistAgentKeyStore();

  return res.status(200).json({
    success: true,
    agentId: record.agentId,
    maskedKey: record.maskedKey,
    status: record.status,
    quickAccessEnabled: record.quickAccessEnabled,
    floatingIconEnabled: record.floatingIconEnabled,
  });
});

// Revoke key
app.post('/api/agent/key/revoke', (req: Request, res: Response) => {
  const agentId = String(req.body?.agentId || '101');
  agentKeyStore.delete(agentId);
  persistAgentKeyStore();
  return res.status(200).json({ success: true });
});

// Execute a WORK Agent command (requires valid active access key)
app.post('/api/agent/command', async (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization || '';
    const bearerKey = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
    const {
      agentId = '101',
      command,
      history = [],
      requestedModel,
    } = req.body || {};

    if (!bearerKey) {
      return res.status(401).json({
        success: false,
        error: 'Missing Agent Access Key. Generate and activate a key in Enables.',
      });
    }

    const record = agentKeyStore.get(String(agentId));
    if (!record || hashAccessKey(bearerKey) !== record.keyHash) {
      return res.status(401).json({
        success: false,
        error: 'Access key could not be verified. Please regenerate your key in Enables.',
      });
    }

    if (record.status !== 'active') {
      return res.status(403).json({
        success: false,
        error: 'Access key is currently Inactive. Enable the key in the WORK dashboard first.',
      });
    }

    if (!command || typeof command !== 'string' || !command.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Please enter or speak a command for the WORK Agent.',
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(200).json({
        success: false,
        error: 'GEMINI_API_KEY is not configured in Settings > Secrets.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const modelToUse =
      typeof requestedModel === 'string' && CANDIDATE_MODELS.includes(requestedModel)
        ? requestedModel
        : 'gemini-4-hydrogen';

    const recentHistoryText = Array.isArray(history)
      ? history
          .slice(-8)
          .map((m: any) => `${m.role === 'user' ? 'User' : `Agent ${agentId}`}: ${m.content}`)
          .join('\n')
      : '';

    const prompt = [
      recentHistoryText ? `Recent WORK Agent #${agentId} History:\n${recentHistoryText}\n` : '',
      `New Command: "${command.trim()}"`,
    ]
      .filter(Boolean)
      .join('\n');

    const response = await ai.models.generateContent({
      model: modelToUse,
      contents: prompt,
      config: {
        systemInstruction:
          `You are NOVA WORK Agent #${agentId}, connected via an authenticated Quick Access key.\n` +
          `Interpret the user's natural language command and return structured JSON.\n` +
          `Supported actions:\n` +
          `1. "open_url": When the user asks to open a web app or website (e.g., ChatGPT -> https://chatgpt.com, YouTube -> https://www.youtube.com, Google -> https://www.google.com, GitHub -> https://github.com, Gmail -> https://mail.google.com, or any explicit domain/website).\n` +
          `2. "search_web": When the user asks to search the internet or look something up -> url MUST be "https://www.google.com/search?q=" + URL-encoded query, and query set to the search terms.\n` +
          `3. "navigate_app": When the user asks to switch to a screen inside NOVA itself -> targetView must be one of "chat", "settings", "pricing", "voice", "enables", "cart".\n` +
          `4. "unsupported_device_action": If the user asks for an OS-level / native Android hardware or background action that a web browser cannot execute directly (e.g., changing phone Wi-Fi/Bluetooth, taking a system screenshot, reading SMS, drawing over other native apps, force-closing another app). NEVER pretend you executed an unsupported device action; clearly state it requires native Android system permissions not available from the web client.\n` +
          `5. "chat_reply": For general questions, brainstorming, or conversational help.\n` +
          `Keep replies crisp, honest, and 1-3 sentences.`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            actionType: {
              type: Type.STRING,
              description:
                'One of: open_url, search_web, navigate_app, chat_reply, unsupported_device_action',
            },
            label: {
              type: Type.STRING,
              description: 'Short button label such as "Open YouTube" or "Search Google"',
            },
            url: {
              type: Type.STRING,
              description: 'Safe https:// URL for open_url or search_web actions',
            },
            targetView: {
              type: Type.STRING,
              description: 'For navigate_app: chat, settings, pricing, voice, enables, or cart',
            },
            query: {
              type: Type.STRING,
              description: 'Search query string for search_web actions',
            },
            reply: {
              type: Type.STRING,
              description: 'Clear, helpful response message from Agent #101',
            },
          },
          required: ['actionType', 'label', 'reply'],
        },
      },
    });

    const parsed = JSON.parse((response.text || '{}').trim());
    const allowedActions = [
      'open_url',
      'search_web',
      'navigate_app',
      'chat_reply',
      'unsupported_device_action',
    ];
    const actionType = allowedActions.includes(parsed.actionType)
      ? parsed.actionType
      : 'chat_reply';

    const safeUrl =
      (actionType === 'open_url' || actionType === 'search_web') && isSafeHttpsUrl(parsed.url)
        ? parsed.url
        : actionType === 'search_web' && parsed.query
        ? `https://www.google.com/search?q=${encodeURIComponent(String(parsed.query))}`
        : undefined;

    const validViews = ['chat', 'settings', 'pricing', 'voice', 'enables', 'cart', 'work'];
    const targetView =
      actionType === 'navigate_app' && validViews.includes(parsed.targetView)
        ? parsed.targetView
        : undefined;

    return res.status(200).json({
      success: true,
      agentId: record.agentId,
      reply: parsed.reply || 'Command processed by WORK Agent.',
      action:
        actionType === 'chat_reply'
          ? undefined
          : {
              type: actionType,
              label: parsed.label || 'Continue',
              url: safeUrl,
              targetView,
              query: parsed.query,
            },
    });
  } catch (error: any) {
    console.error('Error in /api/agent/command:', error);
    return res.status(200).json({
      success: false,
      error: error?.message || 'Failed to process WORK Agent command.',
    });
  }
});

// WORK Full-Screen Agent Execution Endpoint (multi-step planning + real search grounding + honest capability bounds)
app.post('/api/work/execute', async (req: Request, res: Response) => {
  try {
    const {
      agentId = '101',
      command,
      history = [],
      requestedModel,
    } = req.body || {};

    if (!command || typeof command !== 'string' || !command.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Please enter or speak a command for your WORK Agent.',
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(200).json({
        success: false,
        error: 'GEMINI_API_KEY is not configured in Settings > Secrets.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const normalizedModel =
      typeof requestedModel === 'string' && CANDIDATE_MODELS.includes(requestedModel)
        ? requestedModel
        : 'gemini-4-hydrogen';

    const recentHistoryText = Array.isArray(history)
      ? history
          .slice(-6)
          .map((h: any) => `- "${h.command}" -> ${h.status} (${h.targetAppOrSite || h.actionType || 'reply'})`)
          .join('\n')
      : '';

    const planPrompt = [
      recentHistoryText ? `Recent Agent #${agentId} Commands:\n${recentHistoryText}\n` : '',
      `User Command: "${command.trim()}"`,
    ]
      .filter(Boolean)
      .join('\n');

    const planResponse = await ai.models.generateContent({
      model: normalizedModel,
      contents: planPrompt,
      config: {
        systemInstruction:
          `You are WORK Agent #${agentId}, an AI control center inside NOVA AI Assistant.\n` +
          `Analyze the user's natural language command and return structured JSON describing your execution plan.\n` +
          `Available actionType values:\n` +
          `1. "open_url": User wants to open an external web application or website (examples: ChatGPT -> https://chatgpt.com, Google -> https://www.google.com, YouTube -> https://www.youtube.com, GitHub -> https://github.com, Gmail -> https://mail.google.com, WhatsApp Web -> https://web.whatsapp.com, Wikipedia -> https://www.wikipedia.org, or any domain/website mentioned).\n` +
          `   - Set isSupported: true, requiresPermission: true, url: exact valid https:// URL, targetAppOrSite: friendly app/site name.\n` +
          `2. "navigate_app": User wants to open or navigate to a screen inside NOVA AI Assistant itself ("settings", "pricing", "cart", "enables", "voice", or "chat" for home/chat).\n` +
          `   - Set isSupported: true, requiresPermission: false, targetView: one of "chat", "settings", "pricing", "voice", "enables", "cart".\n` +
          `3. "search_web": User wants to search the internet or find real-time / factual information.\n` +
          `   - Set isSupported: true, requiresPermission: false, query: clean search query, url: "https://www.google.com/search?q=" + URL-encoded query, targetAppOrSite: "Web Search".\n` +
          `4. "unsupported_device_action": User asks for a hardware, OS-level, or private native app action that a web browser CANNOT execute directly without native device privileges (e.g., toggle Wi-Fi/Bluetooth/flashlight, make phone calls, read/send native SMS, uninstall apps, change phone volume, take system screenshots, silently control native apps in the background).\n` +
          `   - Set isSupported: false, requiresPermission: false, unsupportedReason: honest explanation of why browser sandbox cannot perform this action, alternativeSuggestion: practical web alternative (e.g., open Settings manually or use a web version if one exists).\n` +
          `5. "chat_reply": Conversational question, drafting, brainstorming, or general assistance that doesn't require opening a URL or searching the web.\n` +
          `   - Set isSupported: true, requiresPermission: false.\n` +
          `CRITICAL HONESTY RULE: Never claim a native OS or device action was completed when running in a web environment.`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            interpretedIntent: {
              type: Type.STRING,
              description: 'Concise 1-sentence summary of what the user asked to do.',
            },
            targetAppOrSite: {
              type: Type.STRING,
              description: 'Identified application, website, NOVA section, or topic name.',
            },
            actionType: {
              type: Type.STRING,
              description: 'One of: open_url, navigate_app, search_web, unsupported_device_action, chat_reply',
            },
            isSupported: {
              type: Type.BOOLEAN,
              description: 'Whether the action can genuinely be executed or launched from NOVA web runtime.',
            },
            requiresPermission: {
              type: Type.BOOLEAN,
              description: 'True when launching an external site/app in a new tab.',
            },
            actionLabel: {
              type: Type.STRING,
              description: 'Button label like "Open ChatGPT", "Open Settings", "Open Search Results".',
            },
            url: {
              type: Type.STRING,
              description: 'Safe https:// URL when actionType is open_url or search_web.',
            },
            targetView: {
              type: Type.STRING,
              description: 'For navigate_app: chat, settings, pricing, voice, enables, or cart.',
            },
            query: {
              type: Type.STRING,
              description: 'Clean search query when actionType is search_web.',
            },
            reply: {
              type: Type.STRING,
              description: 'Clear 1-3 sentence agent response explaining the plan or answer.',
            },
            unsupportedReason: {
              type: Type.STRING,
              description: 'Honest explanation if isSupported is false.',
            },
            alternativeSuggestion: {
              type: Type.STRING,
              description: 'Helpful alternative suggestion if isSupported is false.',
            },
          },
          required: ['interpretedIntent', 'targetAppOrSite', 'actionType', 'isSupported', 'requiresPermission', 'actionLabel', 'reply'],
        },
      },
    });

    const parsed = JSON.parse((planResponse.text || '{}').trim());
    const allowedActions = [
      'open_url',
      'navigate_app',
      'search_web',
      'unsupported_device_action',
      'chat_reply',
    ];
    const actionType = allowedActions.includes(parsed.actionType)
      ? parsed.actionType
      : 'chat_reply';

    const safeUrl =
      (actionType === 'open_url' || actionType === 'search_web') && isSafeHttpsUrl(parsed.url)
        ? parsed.url
        : actionType === 'search_web' && parsed.query
        ? `https://www.google.com/search?q=${encodeURIComponent(String(parsed.query))}`
        : undefined;

    const validNavViews = ['chat', 'settings', 'pricing', 'voice', 'enables', 'cart'];
    const targetView =
      actionType === 'navigate_app' && validNavViews.includes(parsed.targetView)
        ? parsed.targetView
        : undefined;

    let finalReply = parsed.reply || `Processed command for ${parsed.targetAppOrSite || 'task'}.`;
    const groundingSources: { title: string; url: string }[] = [];

    // For search_web, run live Google Search grounding so the user gets real verified information inside the workspace
    if (actionType === 'search_web') {
      try {
        const searchQueryText = String(parsed.query || command.trim());
        const searchResponse = await ai.models.generateContent({
          model: normalizedModel,
          contents: `Provide a crisp, accurate, helpful summary answering: "${searchQueryText}"`,
          config: {
            tools: [{ googleSearch: {} }],
            systemInstruction: `You are WORK Agent #${agentId}. Summarize real search findings clearly in 2-4 concise sentences or bullet points.`,
          },
        });

        if (searchResponse.text) {
          finalReply = searchResponse.text;
        }
        const chunks = (searchResponse.candidates?.[0] as any)?.groundingMetadata?.groundingChunks;
        if (Array.isArray(chunks)) {
          for (const chunk of chunks) {
            if (chunk?.web?.uri && isSafeHttpsUrl(chunk.web.uri)) {
              groundingSources.push({
                title: chunk.web.title || chunk.web.uri,
                url: chunk.web.uri,
              });
            }
          }
        }
      } catch (searchErr) {
        console.warn('WORK search grounding fallback:', searchErr);
      }
    }

    return res.status(200).json({
      success: true,
      agentId: String(agentId),
      interpretedIntent: parsed.interpretedIntent || command.trim(),
      targetAppOrSite: parsed.targetAppOrSite || 'WORK Task',
      actionType,
      isSupported: actionType === 'unsupported_device_action' ? false : Boolean(parsed.isSupported ?? true),
      requiresPermission: Boolean(parsed.requiresPermission),
      actionLabel: parsed.actionLabel || 'Continue',
      url: safeUrl,
      targetView,
      query: parsed.query,
      reply: finalReply,
      groundingSources,
      unsupportedReason: parsed.unsupportedReason,
      alternativeSuggestion: parsed.alternativeSuggestion,
    });
  } catch (error: any) {
    console.error('Error in /api/work/execute:', error);
    return res.status(200).json({
      success: false,
      error: error?.message || 'Failed to execute WORK Agent command.',
    });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NOVA server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
