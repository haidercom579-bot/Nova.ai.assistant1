import {
  AgentActionType,
  GroundingSource,
  WorkAgentProfile,
  WorkCommandExecution,
} from '../types';

const KEYS = {
  AGENTS: 'nova_work_agents_v1',
  ACTIVE_AGENT_ID: 'nova_work_active_agent_id_v1',
  EXECUTIONS: 'nova_work_executions_v1',
};

export interface WorkExecuteApiResult {
  success: boolean;
  agentId?: string;
  interpretedIntent?: string;
  targetAppOrSite?: string;
  actionType?: AgentActionType;
  isSupported?: boolean;
  requiresPermission?: boolean;
  actionLabel?: string;
  url?: string;
  targetView?: 'chat' | 'settings' | 'pricing' | 'voice' | 'enables' | 'cart';
  query?: string;
  reply?: string;
  groundingSources?: GroundingSource[];
  unsupportedReason?: string;
  alternativeSuggestion?: string;
  error?: string;
}

export const WorkAgentService = {
  getAgents(): WorkAgentProfile[] {
    try {
      const raw = localStorage.getItem(KEYS.AGENTS);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  },

  saveAgents(agents: WorkAgentProfile[]): void {
    try {
      localStorage.setItem(KEYS.AGENTS, JSON.stringify(agents));
    } catch (e) {
      console.error('Failed to persist WORK agents:', e);
    }
  },

  getActiveAgentId(): string | null {
    try {
      return localStorage.getItem(KEYS.ACTIVE_AGENT_ID);
    } catch {
      return null;
    }
  },

  setActiveAgentId(agentId: string | null): void {
    try {
      if (agentId) {
        localStorage.setItem(KEYS.ACTIVE_AGENT_ID, agentId);
      } else {
        localStorage.removeItem(KEYS.ACTIVE_AGENT_ID);
      }
    } catch (e) {
      console.error('Failed to persist active agent ID:', e);
    }
  },

  getNextNumericAgentId(existingAgents: WorkAgentProfile[]): string {
    const numericIds = existingAgents
      .map((a) => parseInt(a.id, 10))
      .filter((n) => !Number.isNaN(n) && n >= 101);
    if (numericIds.length === 0) return '101';
    const maxId = Math.max(...numericIds);
    return String(maxId + 1);
  },

  createAgent(existingAgents: WorkAgentProfile[]): WorkAgentProfile {
    const id = this.getNextNumericAgentId(existingAgents);
    const now = Date.now();
    return {
      id,
      name: `AGENT ${id}`,
      createdAt: now,
      termsAcceptedAt: now,
      requirePermissionForExternal: true,
    };
  },

  getExecutions(): WorkCommandExecution[] {
    try {
      const raw = localStorage.getItem(KEYS.EXECUTIONS);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  },

  saveExecutions(executions: WorkCommandExecution[]): void {
    try {
      localStorage.setItem(KEYS.EXECUTIONS, JSON.stringify(executions.slice(0, 80)));
    } catch (e) {
      console.error('Failed to persist WORK command history:', e);
    }
  },

  async executeCommand(params: {
    agentId: string;
    command: string;
    history: WorkCommandExecution[];
    requestedModel: string;
  }): Promise<WorkExecuteApiResult> {
    try {
      const res = await fetch('/api/work/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: params.agentId,
          command: params.command,
          history: params.history.slice(0, 8).map((h) => ({
            command: h.command,
            status: h.status,
            targetAppOrSite: h.targetAppOrSite,
            actionType: h.actionType,
          })),
          requestedModel: params.requestedModel,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || 'WORK Agent could not process the command.',
        };
      }
      return data as WorkExecuteApiResult;
    } catch (e: any) {
      return {
        success: false,
        error: e?.message || 'Network error while reaching WORK Agent.',
      };
    }
  },
};
